classdef StyledPlotObject
  %STYLEDPLOTOBJECT Summary of this class goes here
  %   Detailed explanation goes here
  
  properties
    PlotStyle
  end
  
  methods
  end
  
end

